# ISST-GRUPO05-CASO-2
Repositorio hecho por el Grupo 05 para la realización del caso 2 Resumen.es
